# Cadence platform

The architecture spec for Cadence as an advanced-English platform: pronunciation
(existing), grammar by CEFR level, sentence building, matching, quizzes,
flashcards with spaced repetition, coach conversations and the mouth map, on web,
desktop (Electron) and mobile (Expo) from one content model.

Every builder reads this first. When code and this file disagree, fix one of
them in the same change. Product decisions here are the owner's and final;
anything marked **Open** needs the owner.

Production: `https://cadence.pstepanov.dev`, Firebase project `cadence-pstepanov`.

---

## 1. Principles

1. **Your own Cadence first.** A paired Cadence desktop or server on the
   learner's network runs scoring, TTS, transcription and the coach locally,
   free, for everyone, Plus or not.
2. **The cloud is for Plus, and capped.** Without a reachable Cadence, AI runs
   on the Cadence cloud only with Cadence Plus, within daily quotas and behind a
   global circuit breaker.
3. **Practice never needs AI.** Lessons, quizzes, matching, sentence building,
   flashcards, the sounds library and the mouth map work offline from static
   content packs, in every mode, for free.
4. **Progress follows the account.** Signed-in progress lives in Firestore;
   free accounts get one small summary document, Plus gets everything. People
   who never sign in keep progress on the device or their paired server.
5. **Static where possible.** Content is generated offline, validated, shipped
   as versioned JSON packs and served from the CDN. Nothing per request costs
   money unless it has to.

---

## 2. Shared modules

Pure TypeScript shared by every client lives in two byte-identical copies:

| Server / web / desktop | Mobile | What |
| --- | --- | --- |
| `src/lib/platform/content-model.ts` | `mobile/src/platform/content-model.ts` | CEFR, ids, topics, grammar points, lessons, exercise kinds, packs, `validatePackContent`, `gradeExercise` |
| `src/lib/platform/engine-routing.ts` | `mobile/src/platform/engine-routing.ts` | `routeRequest`, `resolvePlus`, `dataTier`, quotas, audio limits and sniffing |
| `src/lib/platform/progress-model.ts` | `mobile/src/platform/progress-model.ts` | the summary document and `applyActivity` |
| `src/lib/platform/vocal-tract/*` | `mobile/src/platform/vocal-tract/*` | the mouth-map model (section 13) |
| `src/lib/platform/srs.ts` | `mobile/src/platform/srs.ts` | the trimmed SM-2 (`review` with again, hard, good and easy, `planSession`, `summarizeDeck`); `mobile/src/games/srs.ts` and the web's `src/components/learn-hub/srs.ts` re-export it |
| `src/lib/platform/daily-plan.ts` | `mobile/src/platform/daily-plan.ts` | `buildDailyPlan`: today's 10 to 15 minutes (section 7) |
| `src/lib/platform/placement.ts` | `mobile/src/platform/placement.ts` | the adaptive test (`nextPlacementItem`, `placementDone`, `estimateAbility`, `adaptiveResult`), the seen-items encoding (`encodeSeen`, `decodeSeen`, `mergeSeen`), and the older `writtenLevel`, `writtenScore`, `writtenConfidence`, `combineLevels` (section 7) |
| `src/lib/platform/levels.ts` | `mobile/src/platform/levels.ts` | `LEVEL_INFO` (description and approximate IELTS and TOEFL iBT per level), `LevelPrefs` (overall and per-skill levels), `parseLevelPrefs`, `levelFor`, `withLevel`, `newerLevelPrefs`, `prefsFromPlacement` (section 7.1) |
| `src/lib/platform/phrase-bank.ts` | `mobile/src/platform/phrase-bank.ts` | phrase and slang records and validators, search, phrase drills and their grading, slang quizzes, result-to-grade mapping, the practice list (section 17) |
| `src/lib/platform/fossilization.ts` | `mobile/src/platform/fossilization.ts` | the plateau track: evidence, `diagnose`, the diagnostic, `startTrack`, weeks and phases, `dailyDrills`, own sentences, re-tests, `errorProgress` (section 18) |
| `src/lib/platform/practice-day.ts` | `mobile/src/platform/practice-day.ts` | `buildPracticeDay` (today's advanced drill list) and `spokenSteps` (sections 17, 18 and 20) |
| `src/lib/platform/goals.ts` | `mobile/src/platform/goals.ts` | the setup's learning goals (one or more, `learningGoals` on the account), `parseGoals`, migration from the older single `practiceFocus` (`goalsFromFocus`, `focusForGoals`), and `goalEmphasis` for the daily plan |
| `src/lib/platform/recordings.ts` | `mobile/src/platform/recordings.ts` | the recordings index every store keeps, limits and eviction, grouping, and the metadata Plus syncs (section 19) |

Rules, enforced by `tests/platform/drift.test.ts`:

- The copies match from the first `/**` to the end of the file. Only the
  header (the `// FILE:` and `// Twin:` lines) differs.
- Edit the `src/lib/platform/` copy, then run
  `node scripts/platform/sync-mobile.mjs` (`--check` fails on a stale copy).
- They import each other only as `./x.ts`. Node's test runner, Metro and Next
  all resolve that; the root `tsconfig.json` has `allowImportingTsExtensions`
  for it.
- No Node, DOM, React or React Native APIs, so they run in all three apps
  and in `node --test`.

There is one scheduler: `tests/platform/drift.test.ts` also fails on any
other `review` function or SM-2 interval rule under `src/` or `mobile/src/`.
The web's `/today` (`src/components/advanced/TodayPlan.tsx`) calls `buildDailyPlan` with this browser's data. **Open:** the phone's Home screen does not call it yet.

---

## 3. Content model

Types are in `content-model.ts`. All content is written in our own words or
comes from openly licensed sources (section 3.5).

**CEFR level.** `A1 A2 B1 B2 C1 C2`. Every grammar point, lesson and exercise
has exactly one level.

**Ids.** `<prefix>.<slug>`, lowercase, at most 96 characters, permanent.
Prefixes: `topic`, `gp` (grammar point), `lesson`, `ex` (exercise), `card`,
`sound`, `scenario`. Progress and SRS state are keyed by id, so content is
fixed by editing in place, never by renaming. A removed id stays reserved.

| Entity | Key fields |
| --- | --- |
| Topic | `id`, `title`, `summary` |
| Grammar point | `id`, `level`, `topicId`, `title`, `summary` (one line), `explanation`, `patterns[]`, `examples[]` (at least two), `commonErrors[]` (`wrong`, `right`, `note`), `related[]` |
| Lesson | `id`, `level`, `topicId`, `title`, `goal`, `minutes` (1-30), `grammarPointIds[]`, `soundIds[]`, `exerciseIds[]` |
| Example | `text`, `note?`, `source` (`generated` or `tatoeba` with `sentenceId` and `author`), `audio?` |
| Scenario (coach) | `id`, `level`, `title`, `role` (who the coach plays), `learnerRole`, `goal`, `usefulPhrases[]`, `opening` |

### 3.1 Exercise kinds

Every exercise has `id`, `kind`, `level`, `grammarPointIds[]`, `soundIds?`,
`prompt`, `explanation?`. Kind-specific fields and how they are graded
(`gradeExercise`, with typed answers compared through `normalizeAnswer`:
NFKC, case folded, curly quotes straightened, whitespace collapsed, final
punctuation dropped; contractions are not expanded, so accepted answers list
both forms):

| Kind | Fields | Answer | Correct when |
| --- | --- | --- | --- |
| `multiple_choice` | `passage?` (reading items, at most 480 characters, shown above the question), `question`, `options[2..6]`, `answer` (index) | `choice` | index matches |
| `matching` | `pairs[2..8]` of `left`/`right` | `mapping[i]` = chosen right index | all pairs; partial score per pair |
| `gap_fill` | `text` with `___` per gap, `answers[gap][]`, `bank?` | `gaps[]` | every gap matches an accepted answer; partial score per gap |
| `sentence_building` | `answer` tokens in order (3-16), `alternatives?`, `distractors?` | `tokens[]` | equals the answer or an alternative |
| `error_correction` | `sentence`, `answers[]` | `text` | matches an accepted answer |
| `transformation` | `source`, `instruction`, `answers[]` | `text` | matches an accepted answer |
| `dictation` | `text`, `audio` | `text` | word accuracy (1 - word edit distance / length) at least 0.9; score is the accuracy |
| `minimal_pair` | `words[2]`, `soundIds[2]`, `audio[2]` | `played`, `choice` | the learner picked the word that was played |
| `flashcard` | `front`, `back`, `example?`, `audio?` | `grade` (`again`, `hard`, `good`, `easy`) | self-graded; anything but `again` counts as recalled and feeds SRS |

Grading runs on the device for every kind (no network, no cost) and on the
server only for the MCP quiz tools. Spoken answers (shadowing, the coach)
are scored by the engines, not by `gradeExercise`.

### 3.2 Validation

`validatePackContent` (ids, uniqueness, references, levels, text limits) and
`validateExercise` (each kind's own rules: answer indexes in range, one answer
list per gap, distractors not in the answer, alternatives use the same tokens,
minimal pairs actually differ) run in the content pipeline and in tests. A pack
with any problem does not build. Further pipeline checks, in
`scripts/content/validate.mjs` (content builder):

- every Tatoeba example has a `sentenceId` that exists in the downloaded
  export, and its author is credited;
- no example, explanation or exercise repeats text from a word list we may not
  use (no Oxford 3000/5000, no Cambridge lists; we never import them, and the
  pipeline does not prompt with them);
- generated text passes a second Gemini pass that answers each exercise blind;
  disagreements with the key are dropped or rewritten, never shipped.

### 3.3 Content packs

Content is static JSON: shipped inside each app, served by the web, cached by
the CDN, readable offline, and never read from Firestore.

```
public/packs/index.json                                   PackIndex, short cache (5 min)
public/packs/<packId>/v<version>/manifest.json             PackManifest
public/packs/<packId>/v<version>/content.json              PackContent
public/packs/<packId>/v<version>/audio/<sha256-16>.m4a     pre-generated audio
```

- Packs: `sounds` (articulation targets, minimal pairs, sounds library audio),
  `placement` (the placement test's bank, section 7; exercises only, never
  used by quizzes, lookups or the MCP tools, so a retake meets fresh items),
  `core-a1` … `core-c2` (topics, grammar points, lessons, exercises,
  flashcards, scenarios for that level), and the advanced packs:
  `phrases-b2`, `phrases-c1`, `phrases-c2` (the phrase bank, section 17),
  `slang` (section 17) and `fossilization` (the plateau track, section 18).
  These carry their data in `content.json` beside the four standard lists,
  which stay empty, and have no `level`, so nothing that looks a level up
  ever picks one.
- `manifest.json` lists every file with its SHA-256 and size. `version` is an
  integer that only goes up; any changed file means a new version directory.
  Versioned paths are immutable (`Cache-Control: public, max-age=31536000,
  immutable`).
- `format` (`PACK_FORMAT_VERSION`) is the container; `contentModel`
  (`CONTENT_MODEL_VERSION`) is the schema. `canReadPack` skips any pack the app
  does not understand rather than half-reading it; `packsToUpdate` picks the
  ones with a newer version.
- Mobile bundles `sounds`, `placement`, `core-a1` … `core-b2` and the advanced packs in the binary and downloads
  `core-c1`, `core-c2` and newer versions on demand into the documents
  directory (the "offline content packs" setting lists them with sizes and a
  remove button). Desktop bundles all packs in the standalone build. The web
  fetches `index.json` and caches packs with a service worker.
- Audio (lesson sentences, flashcards, minimal pairs, sound models) is
  generated once at build time with Google Cloud Text-to-Speech and named by
  the hash of `voice|rate|text`, so a rebuild reuses it.

Size budgets are in section 16.

### 3.4 Content pipeline

`scripts/content/` (content builder), run by hand, never at request time:

1. `generate.mjs` drafts grammar points, lessons and exercises per level with
   Gemini (`GEMINI_API_KEY` read from `~/.config/pstepanov/gemini.env`, never
   printed), in our own words, against a fixed outline of grammar points per
   level.
2. `placement.mjs` drafts the placement bank (section 7) per level in seven
   item types, puts it through the same blind check (`lib/blind-check.mjs`,
   shared with `check.mjs`) and a level check (a second model rates each
   item's CEFR level; more than one level away from its band is dropped),
   into `content/placement/<level>.json`.
3. `tatoeba.mjs` pulls English sentences from the Tatoeba export (CC BY 2.0
   FR), keeps id and author, and attaches them as examples where a grammar
   point matches.
4. `validate.mjs` runs section 3.2, plus the placement coverage (at least 60
   items and all seven types per level). `build.mjs` writes the pack, hashes
   files, bumps the version only when something changed.
5. `audio.mjs` synthesizes missing audio (owner runs it; it costs money).

### 3.5 Sources and credit

Our own generated text, Tatoeba sentences (CC BY 2.0 FR, credited per
sentence in `CREDITS.md` and in the pack), and the articulation sources in
section 13. No copyrighted word lists. Every source is added to `CREDITS.md`
in the change that brings it in.

---

## 4. Accounts, data tiers and entitlement

### 4.1 Tiers

`dataTier(signedIn, plus)` in `engine-routing.ts`:

| Who | Tier | Cloud keeps | Device or paired server keeps |
| --- | --- | --- | --- |
| Not signed in | `none` | nothing | everything (as today) |
| Signed in, free | `summary` | one summary document | SRS state, attempts, mastery, coach history |
| Signed in, Plus | `full` | everything, synced across devices | a cache |

- **Upgrade.** When Plus first becomes active on a device, the app uploads its
  local detail once (`POST /api/sync/import`, idempotent per install id), then
  syncs normally.
- **Lapse.** The summary keeps updating. Detailed sync stops; detailed cloud
  data is kept `LAPSED_RETENTION_DAYS` (90) and then deleted by the daily job
  (section 12). Renewing within 90 days resumes sync with nothing lost. The
  privacy policy says this in those words.
- Transcripts are stored only as part of Plus progress (coach summaries,
  spoken-grammar feedback), never for free accounts, never by default for
  scoring.

### 4.2 Entitlement

- Plus products: `dev.pstepanov.cadence.plus.monthly` ($14.99/month) and
  `dev.pstepanov.cadence.plus.yearly` ($99.99/year, 7-day trial). iOS through
  RevenueCat (`react-native-purchases`, entitlement `plus`, offering
  `default`); web through Stripe Checkout and the Customer Portal (prices by
  lookup key `cadence_plus_monthly` / `cadence_plus_yearly`; the yearly session
  sets `subscription_data.trial_period_days = 7` only for a customer who never
  had a trial; product `metadata.app = cadence`; portal return URL `/account`).
- The truth is server-side: each verified webhook writes its own source at
  `users/{uid}.plusSources.<stripe|app_store>` (a `PlusRecord`:
  `{active, source, productId, expiresAt, willRenew, updatedAt}`) and, in the
  same transaction, `users/{uid}.plus = resolvePlus(plusSources, now)`. Plus
  if any source is active and its period has not ended.
- **Friend codes** are the third source, `plusSources.code` (productId
  `dev.pstepanov.cadence.plus.code`, `willRenew` false, plus the `codeId`
  that wrote it), written by `src/lib/server/codes/store.ts` in the same kind
  of transaction, so `resolvePlus` still decides alone. A code gives a whole
  number of days, 1 to 730, never Plus for life; redeeming extends a running
  code grant and never touches a purchase; when the code is the only active
  source, `detailPurgeAt` is set to 90 days after it ends. Codes are made on
  the owner's dashboard (pstepanov.dev/dashboard/apps/cadence) through
  `/api/admin/codes` with `ADMIN_SECRET`, and redeemed only on the website's
  `/redeem` (`/api/codes/redeem`, signed in, ten tries an hour per account and thirty per address). The iPhone
  app never mentions or takes codes.
- Clients never write entitlement. They read `plus` from `GET /api/me` and,
  on iOS, use RevenueCat's customer info only to update the UI immediately
  after a purchase; the server stays authoritative.
- After sign-in the iOS app calls `Purchases.logIn(uid)` (and `logOut` on
  sign-out), so `app_user_id` is the Firebase uid.
- Connecting your own Cadence is free forever and open source. In the iOS app
  it is "Connect your own Cadence", never presented as a way around
  paying. No promo or friend codes anywhere in the native apps.

---

## 5. Firestore data model

All access is through the Admin SDK on the server; `firestore.rules` denies
every client (section 14). Documents are sized so a session costs a handful of
reads.

| Path | Who | Contents | Reads |
| --- | --- | --- | --- |
| `users/{uid}` | all | profile (existing fields, plus `levels`: the `LevelPrefs` of section 7.1, and `placementSeen`: the compact seen-items string, under 1 KB), `plus`, `plusSources`, `stripeCustomerId`, `rcAppUserId`, `detailPurgeAt?` | 1 per session |
| `users/{uid}/progress/summary` | all signed in | `ProgressSummary` (`progress-model.ts`): streak, minutes, lessons per level, placement level, last active, 20 most recent results; under 8 KB | 1 per session |
| `users/{uid}/inbox/flashcards` | all signed in | cards added through MCP, waiting for a device (at most 200; deleted once delivered) | 1 per open, usually missing |
| `users/{uid}/practice/inbox` | all signed in | `list`: the practice list the connector assigned (`PracticeListItem[]`, at most 200); `reviews`: drill results the connector logged for a free account, waiting for a device (at most 200) (section 20) | 1 per open of the advanced screens |
| `users/{uid}/advanced/state` | Plus | `cards` (phrase and slang review state, `CardState & {updatedAt}`), `track` (the plateau `Track`), `recordings` (`RecordingMeta[]`, at most 500, never audio or file names), `updatedAt`, `lastInstallId`; one document, well under 1 MiB (section 20) | 1 per sync and per Plus teacher tool |
| `users/{uid}/srs/{packId}` | Plus | `cards: {cardId: CardState & {updatedAt}}`, one document per pack (about 70 bytes a card, well under 1 MiB) | 1 per pack in use |
| `users/{uid}/mastery/sounds` | Plus | `{soundId: {attempts, ema, best, lastAt, history: [{day, score}] (30 days)}}` | 1 when needed |
| `users/{uid}/mastery/grammar` | Plus | `{gpId: {attempts, correct, ema, lastAt}}` | 1 when needed |
| `users/{uid}/attempts/{YYYY-MM-DD}` | Plus | `items: Attempt[]` appended with `arrayUnion` (overflow to `{day}-2` past 500) | history views only |
| `users/{uid}/coachSessions/{id}` | Plus | scenario, started/ended, turn count, running summary, transcript | history views only |
| `users/{uid}/devices/{installId}` | all signed in | platform, `push` (`{token, timeZone, updatedAt}`, the Expo push token, any tier); with Plus also `lastSyncAt`, `importedAt` | on sync and app open |
| `usage/{uid}/days/{YYYY-MM-DD}` | cloud AI users | `DailyUsage` counters, `expireAt` (+35 days, TTL) | 1 per AI request (in the quota transaction) |
| `system/aiBudget/days/{YYYY-MM-DD}` | server | global estimated spend and request counts, `tripped` | cached 30 s per instance |
| `webhookEvents/{source}:{eventId}` | server | type, uid, received at, `expireAt` (+30 days, TTL) | 1 per webhook |
| `mailQueue/{key}` | server | template, recipient uid, data, status; `key` makes it exactly-once | written by events |
| `oauthClients`, `oauthCodes`, `oauthTokens`, `oauthGrants` | MCP | as the portfolio's `lib/oauth`; tokens as SHA-256 digests | per MCP call |
| `rateLimits/{key}` | server | fixed-window counters with `expireAt` (TTL) | per limited call |
| `friendCodes/{sha256}` | server | a friend code: label, `durationDays`, `maxRedemptions`, `redemptions`, redeem-by `expiresAt`, `disabled`; `redemptions/{uid}` beneath it (uid, email, when, grant end, `revokedAt?`; deleted with the account) | per redemption |
| `supportRequests/{id}` | server | a contact-form message: email, name, topic, message, platform, user agent, `uid?`, `status` (open, answered, closed), `replies[]`; deleted with the account when it has a uid | per message |
| `deletions/{uid}` | server | account deletion steps done, retried by the daily job; no address once finished | on deletion |

`users/{uid}` also holds `emailPrefs` (`reminders`, `newsletter`; reminders are
off until the learner turns them on with `PATCH /api/me`), `security` (last
sign-in email, `tokensValidAfter`, hashed device labels, for the sign-in
notices) and, while the web pages still read it, the older `billing` map,
which the Stripe webhook keeps current.

Notes:

- `usage/{uid}/{day}` from the brief is stored as `usage/{uid}/days/{day}`,
  because Firestore paths alternate collection and document.
- The existing pronunciation collections (`moduleProgress`, `lessonSessions`,
  `lessonAttempts`, `conversationProgress`) become Plus detail. A free account
  writes only the summary; its module progress stays on the device. **Open:**
  the routes that write them (`/api/attempts`, `/api/sessions`, `/api/progress`,
  `/api/conversation-progress`) still write for every cloud account, because
  the web pages read module unlocks from them through `src/lib/learn-data.ts`.
  Gating them needs those reads moved to the device first; the daily job
  already purges them with the rest of the Plus detail after a lapse.
- TTL policies on `expireAt` for `usage`, `webhookEvents`, `rateLimits` and
  `mailQueue`, and on `expiresAt` for `oauthCodes` and `oauthTokens`, are set by
  the owner with `deploy/cloudrun.sh ttl` (docs/DEPLOY.md).

### 5.1 Sync API

All under App Check (section 14) and the Firebase ID token.

| Route | Tier | Does |
| --- | --- | --- |
| `GET /api/me` | all | profile, `plus`, data tier, today's quota left (`src/lib/server/me.ts`; usage and the breaker are read only for Plus on the hosted cloud) |
| `POST /api/sync/summary` | summary, full | `{activities: Activity[]}` (at most 50) applied with `applyActivity` in one transaction, with the per-minute rate limit kept on the same document (`syncSummary`); returns the summary |
| `GET /api/sync/inbox` | all | pending MCP flashcards; `DELETE` acknowledges them |
| `POST /api/sync/push` | full | `{installId, srs?, attempts?, mastery?, coach?}`; cards merge last-writer-wins by `updatedAt`; rate limited on the device document (a new install also against the account) |
| `GET /api/sync/pull?since=` | full | changes since a cursor |
| `POST /api/sync/import` | full | the one-time upload on upgrade |
| `GET /api/practice`, `PATCH /api/practice` | summary, full | the practice inbox (section 20): `{list, reviews}`; PATCH `{reviewsUpTo?, done?}` acknowledges the logged reviews up to a time and removes finished items |
| `GET /api/sync/advanced`, `POST /api/sync/advanced` | full | phrase and slang cards, the plateau track and recording metadata: POST `{installId, cards?, track?, recordings?: {upsert, remove}}` merges (cards by `updatedAt`, the newer track, metadata by id) and answers the merged state; rate limited per account; a free account gets 402 `needs_plus` |

Session cost targets: free 2 reads and 1 write; Plus at most 10 reads and 5
writes. A session is one open (`GET /api/me`) and one synced round, plus the
detail push and pull for Plus; the inbox check is its own read per open.
`tests/server/emulator/session-cost.test.ts` counts them: free 2 reads and
1 write; Plus 13 reads (14 when the breaker cache is cold) and 5 writes.
**Open:** the Plus pull costs 5 reads on its own (the user document and one
query per detail collection, each billed at least one read). Returning the
pull with the push, or skipping it when a `detailChangedAt` on the summary
says nothing changed elsewhere, brings Plus under 10; both need the app.

Other server routes (code in `src/lib/server/`): `PATCH /api/me`
`{reminders}`; `POST /api/auth/password-reset` `{email}`,
`/api/auth/verify-email`, `/api/auth/password-changed` `{email}`,
`/api/auth/sign-in-failed` `{email}` (the sign-in forms report failures; ten
in an hour sends one `suspicious-activity` a day); `GET /api/account/export`,
`DELETE /api/account`, `POST /api/account/email` `{newEmail}`,
`GET`/`DELETE /api/account/connections` (MCP grants); `POST /api/newsletter`
`{email, consent}` or `{subscribed}`; `GET`/`POST /api/email/unsubscribe`;
`POST /api/ai/grammar-feedback`, `POST /api/ai/placement`; `POST /api/support`
`{email, topic, message, name?, platform?}` (the contact form: honeypot
`website`, five an hour per IP and ten a day per address, a signed-in
writer's uid attached, kept in `supportRequests` and queued as
`support-request` to `SUPPORT_INBOX` with the writer as reply-to);
`GET`/`POST /api/codes/redeem` (friend codes, section 4.2). The owner's
dashboard calls `GET`/`POST`/`PATCH /api/admin/codes` (the contract every
app it manages shares: list, create, disable or enable, revoke) and
`GET`/`PATCH`/`POST /api/admin/support` (list by status, set status, reply
by email as `support-reply`), all with `Authorization: Bearer <ADMIN_SECRET>`. `PUT /api/devices`
`{installId, expoPushToken, platform, timeZone}` and `DELETE /api/devices?installId=`
keep a phone's push token (free and Plus); `POST /api/jobs/push` (job secret,
`{uids, title, body, url}`) is the stub future campaigns send through
(`src/lib/server/push.ts`). The daily purge clears `devices` after a Plus lapse;
the app registers its token again on the next open. Errors are
`{error, message}` with a code the apps switch on.

---

## 6. Engine routing

`routeRequest` in `engine-routing.ts` decides where each AI request runs. The
phone and web call it before every AI action; the server enforces the same
rules again (it never trusts the client's decision).

```
if paired Cadence is reachable and reports the capability   -> local
note = paired ? (reachable ? missing capability : unreachable) : none
if this build has no cloud API                               -> blocked cloud_unavailable  [own server]
if not signed in                                             -> blocked needs_sign_in     [own server, sign in]
if not Plus                                                  -> blocked needs_plus        [own server, Plus]
if the global circuit breaker is open                        -> blocked cloud_paused      [own server, retry later]
if today's quota for this capability is used up              -> blocked daily_limit       [own server]
otherwise                                                    -> cloud (with note)
```

`[own server]` is `connect_own_server`, or `reconnect_own_server` when one is
already paired. Capabilities: `score`, `tts`, `transcribe`, `coach`,
`grammar_feedback`, `placement`. Non-AI practice never routes.

Copy (short, ours): daily limit is "Daily limit reached. Connect your own
Cadence for unlimited practice." Needs Plus offers both choices side by side.

**Two transports on the phone.** Today `mobile/src/api/transport.ts` picks one
place for every call. It becomes two: the *AI transport* (paired server or
cloud, per `routeRequest`) and the *account transport* (the cloud API when
signed in, the paired server otherwise). A phone can be paired at home and
signed in at once: AI runs at home, progress follows the account.

### 6.1 Engine interface (server)

`src/lib/server/engines/` defines one interface per capability and
picks a provider by environment variable, so a provider is swapped by config:

| Interface | Providers | Env (default in cloud / own server) |
| --- | --- | --- |
| `SpeechScorer.score(audio, target)` | `local` (ai-engine), `cloud-run` (cadence-ai) | `ENGINE_SCORER` = `cloud-run` / `local` |
| `Transcriber.transcribe(audio)` | `local` (Whisper), `gemini`, `whisper-cpu` (cadence-ai) | `ENGINE_TRANSCRIBER` = `gemini` (benchmark, 6.2) / `local` |
| `Synthesizer.speak(text, voice)` | `local` (OmniVoice), `google-tts` (+ GCS cache) | `ENGINE_TTS` = `google-tts` / `local` |
| `CoachModel.turn(session, input)` | `local` (Qwen), `gemini` | `ENGINE_COACH` = `gemini` / `local` |
| `GrammarAnalyzer.check(transcript, candidates)` | `local` (Qwen), `gemini` | `ENGINE_GRAMMAR` = `gemini` / `local` |

The local engines (Whisper, OmniVoice, Qwen) are unchanged for own-server mode.

### 6.2 Cloud cost architecture

No GPU anywhere in the cloud.

- **Coach turns:** Gemini 2.5 Flash-Lite through Vertex AI (service account,
  no key in the environment). Fixed system prompt per scenario, cached
  (implicit caching, explicit cache when the prompt exceeds the minimum);
  history trimmed to the last 12 turns plus a running summary; at most about
  250 output tokens.
- **Spoken grammar feedback and placement analysis:** Gemini 2.5 Flash, same
  guards, JSON output validated against a schema.
- **Transcription:** Gemini audio input or Whisper-small on CPU, whichever
  wins `scripts/bench/transcribe.mjs` (accuracy first, then latency and cost)
  on an openly licensed English test set. Results go in the table below.
- **Pronunciation scoring:** the existing phoneme model on Cloud Run CPU
  (`cadence-ai`, section 12), model baked into the image.
- **TTS:** Google Cloud Text-to-Speech (one Neural2 or Chirp voice per accent),
  results cached in Cloud Storage by `sha256(voice|rate|text)`. Lesson and
  flashcard audio is pre-generated in the packs, so request-time TTS is rare.
- **Explanations and examples** are generated offline (section 3.4), never per
  request.

**Transcription benchmark.** `node scripts/bench/transcribe.mjs --clips 10`
(2026-10-24): the first 10 clips of LibriSpeech dev-clean (CC BY 4.0, 109.8 s),
sent as the 16 kHz WAV the iOS app records. Gemini through the public API with
the server's prompt; Whisper-small on 2 CPU threads of an M-series Mac, costed
as cadence-ai's 2 vCPU and 4 GiB at Cloud Run prices for the time it was busy
(no cold start, so the real figure is higher).

| Engine | Clips | WER | p50 latency | p95 latency | Cost per audio minute |
| --- | --- | --- | --- | --- | --- |
| Gemini 2.5 Flash-Lite (audio) | 10 | 7.9% | 1.54 s | 2.41 s | $0.00067 |
| Whisper-small, CPU x2 | 10 | 8.7% | 3.55 s | 9.77 s | $0.00138 |

Gemini wins on all three, so `ENGINE_TRANSCRIBER=gemini` in the cloud;
`whisper-cpu` stays available by config.

### 6.3 Quotas and the circuit breaker

- Per user per day, Plus (`PLUS_DAILY_LIMITS`): 30 minutes of audio
  (scoring, transcription, analysis), 20,000 TTS characters, 120 coach turns
  (coach, spoken grammar, placement). Free accounts get no cloud AI.
- The server charges `usageCost(capability, request)` against
  `usage/{uid}/days/{day}` in a transaction before calling the provider and
  refuses with `429 {error: "daily_limit"}` when `checkQuota` says no.
- Global: each instance adds its estimated cost to `system/aiBudget/days/{day}`;
  when the day's total passes `AI_DAILY_BUDGET_USD` it sets `tripped` and every
  cloud AI route answers `503 {error: "cloud_paused"}` until midnight UTC.

---

## 7. AI features

All five run through routing (local engines or cloud), so free users with their
own Cadence get them too.

- **Placement test.** Adaptive, written, free and offline (no AI): items from
  the `placement` pack (at least 60 per level, about 500 in all, in seven
  types: grammar in context, typed gap fill, error spotting, sentence
  transformation, word order, collocation and word choice, reading in
  context), with genuinely hard C1 and C2 items (inversion, clefts, mixed and
  inverted conditionals, the subjunctive, nominalisation, hedging, register,
  idiomatic collocation). `placement.ts` models each answer with one ability
  scale on which a level is one unit wide and an item of that level has its
  difficulty at the level's start (slope 1.7, a guessing floor of one in the
  number of options for multiple choice, none for typed answers), keeps the
  posterior on a grid from a broad prior centred between B1 and B2, and asks
  next an item at the level nearest the estimate, of a type not used in the
  last two answers, never one asked in this test and, while any are left, one
  not seen in an earlier test. It stops after 12 to 24 items, once 80% of the
  estimate lies inside one level. The result is `{level, confidence,
  probability, theta, score, asked, skills: {grammar?, vocabulary?},
  strengths, focus}`; confidence is high from 80%, medium from 60%. Seen ids
  are kept on the device and, signed in, on the account as one compact string
  (per `<level>.<type>`, a base64url bitset of item numbers). The spoken
  sample (`POST /api/ai/placement`, with AI) still moves the written level by
  at most one (`combineLevels`). The result sets the learner's level (7.1)
  and is stored as `placementLevel` in the summary. Scoring is tested with
  simulated learners at every level (`tests/platform/adaptive-placement.test.ts`).
- **Adaptive daily plan.** `daily-plan.ts` (shared, pure): from due flashcards,
  the weakest sounds (mastery EMA times frequency weight) and the weakest
  grammar points, pick 10-15 minutes: due cards first (at most 5 minutes), then
  one or two sounds, one grammar item, then shadowing or a coach scenario if AI
  is available. The learner's goals reorder it: grammar before sounds for a
  grammar or exam goal (with no sound goal), the coach instead of shadowing for
  conversation goals, up to 5 minutes of phrase review to sound natural; with
  no goals the order above is unchanged. Same function on the device (free,
  local data) and with synced data (Plus).
- **Spoken grammar feedback.** After transcription, the analyzer gets the
  transcript and a candidate list of grammar point ids for the learner's level,
  and returns `{issues: [{quote, corrected, grammarPointId, note}]}`. The server
  drops any id not in the packs and any issue whose quote is not in the
  transcript. The app links each issue to its grammar point.
- **Shadowing.** A model sentence with TTS reference audio (pre-generated);
  the learner records over it; scoring compares phonemes and, where the engine
  supports it, stress and pitch contour, shown as a simple arrow line over the
  words.
- **Coach scenarios.** Job interview, small talk, meeting, travel, presentation,
  as `scenario.*` records with role cards (who the coach plays, the learner's
  goal, useful phrases). The coach stays in role and ends with three short
  pointers.

### 7.1 Levels

Six levels everywhere, A1 to C2, always offered advanced first: Cadence is
built for B2 to C2 learners who have plateaued, and A1 and A2 exist for
completeness. The default level, before setup or a test, is B2.

| Level | Name | What it means | IELTS (approx.) | TOEFL iBT (approx.) |
| --- | --- | --- | --- | --- |
| C2 | Proficient | Nuance, register and precision at will. | 8.5 to 9.0 | 114 to 120 |
| C1 | Advanced | Fluent, precise English for work and study. | 7.0 to 8.0 | 95 to 113 |
| B2 | Upper intermediate | Clear, detailed argument on abstract topics. | 5.5 to 6.5 | 72 to 94 |
| B1 | Intermediate | Most everyday situations and simple connected text. | 4.0 to 5.0 | 42 to 71 |
| A2 | Elementary | Routine exchanges on familiar topics. | below 4.0 | below 42 |
| A1 | Beginner | Basic phrases and simple facts. | not reported | below 42 |

Sources: IELTS's own CEFR alignment, "IELTS and the CEFR" on ielts.org (IELTS
reports no CEFR level below B1, so A2 and A1 are shown as below 4.0 and not
reported); ETS's published CEFR mapping of TOEFL iBT total scores (0 to 120:
B1 from 42, B2 from 72, C1 from 95, C2 from 114). The apps label them
approximate, because a CEFR level is a band and the exams measure different
things. **Open:** the owner should check the figures against the current ETS
and IELTS tables before launch, and whether ETS's newer 1 to 6 band score
should be shown beside the 0 to 120 total.

**Level settings** (`levels.ts`, `LevelPrefs`): one overall level, optional
grammar, vocabulary and pronunciation levels (a skill set to the overall level
follows it again), where it came from (`default`, `self`, `placement`) and
`updatedAt`. Set in setup (the self-check of all six levels, or the placement
test, which also sets grammar and vocabulary where they came out different)
and changeable any time: Settings > Level on the phone
(`mobile/src/app/settings/level.tsx`, with Retake placement at
`settings/placement`), Account > Level on the web (`/account/level`,
`/account/level/placement`). Stored by data tier: on the device for everyone
(AsyncStorage `cadence.levels.v1`, localStorage on the web) and, signed in to
the cloud, also on `users/{uid}.levels` through `PATCH /api/profile`; the
newer copy wins both ways (`mobile/src/learning/levels.ts`,
`src/components/levels/level-store.ts`). Own-server mode keeps it on the
device. Everything follows a change at once: the Learn hub, practice and the
grammar browser open on the learner's grammar level (another level is
browsable without changing it), screens without a level parameter use it,
`buildDailyPlan` takes it as `level`, and the coach gets it with every turn
(`level` on `POST /api/ai-coach`, a fixed line per level in the system prompt,
never learner text).

---

## 8. MCP connector

`https://cadence.pstepanov.dev/api/mcp`, modelled on the portfolio
(`lib/oauth`, `app/api/mcp`, `lib/mcp`) and Heft.

- Streamable HTTP, stateless, JSON responses (Cloud Run has no instance
  affinity; nothing lives in memory between requests). `GET` and `DELETE`
  answer 405 after authentication.
- OAuth 2.1: the app is its own authorization server. Dynamic client
  registration is open; no token is minted without the learner signing in to
  Cadence on the consent screen (`/oauth/authorize`, a web page backed by
  `GET`/`POST /api/oauth/authorize`: GET describes the request with the
  learner's ID token as Bearer; POST takes `{...params, decision, scope,
  id_token}` as JSON and answers `{redirect}`). PKCE S256 required.
  Tokens are opaque, stored as SHA-256 digests, audience-bound to
  `https://cadence.pstepanov.dev/api/mcp`, refresh tokens rotate with reuse
  detection, grants end after 180 days. Known product names must redirect to
  their own domains (the portfolio's `client-identity.ts` rules). The list of
  those products is configuration, not code: `OAUTH_KNOWN_CLIENTS` (a JSON
  array of `{label, tokens, hosts, schemes?}`, the `oauth-known-clients`
  secret) is merged with the built-in entries.
- The consent page (`src/app/oauth/authorize/page.tsx`,
  `src/components/oauth/AuthorizeConsent.tsx`) signs in with Firebase if
  needed, shows where the code goes first, then the app's name, the account
  and one checkbox per scope (read is always on), and follows the
  `{redirect}` the server answers. `resource_documentation` is `/connector`.
- Discovery: `/.well-known/oauth-protected-resource/api/mcp` and
  `/.well-known/oauth-authorization-server` (rewrites, as in the portfolio).
  An unauthenticated call gets `401` with
  `WWW-Authenticate: Bearer resource_metadata="https://cadence.pstepanov.dev/.well-known/oauth-protected-resource/api/mcp"`.
- Scopes: `cadence:read` (always), `cadence:write` (adds and logs). Plus is
  checked per call from `users/{uid}.plus`, not from the scope; a Plus tool
  called by a free account returns a tool error "This needs Cadence Plus".
- Rate limits per uid (fixed windows in `rateLimits`): free 30 calls per hour
  and 200 per day, Plus 120 per hour and 2,000 per day. Over the limit:
  JSON-RPC error with `retryAfterSeconds`.

| Tool | Tier | Input | Output |
| --- | --- | --- | --- |
| `get_progress_overview` | free | `{}` | `{plan, streak: {current, best}, totalMinutes, lessonsCompleted: {A1..C2}, placementLevel, lastActiveAt, recent: RecentResult[]}` |
| `get_streak` | free | `{}` | `{current, best, lastDay, activeToday}` |
| `lookup_grammar` | free | `{query (1-100 chars), level?}` | `{matches: [{id, title, level, summary, patterns, examples (3), commonErrors (2), url}]}` from the packs |
| `add_flashcards` | free, write | `{cards: [{front, back, example?}] (1-20)}` | `{queued, note}`; free: inbox, delivered on the next app open; Plus: straight into SRS |
| `start_quiz` | free | `{grammarPointId?, topic?, level?, count (3-10)}` | `{quizId, questions: [{n, kind, prompt, question?, options?, left?, text?, tokens?}]}` (`left` and `options` are matching's two columns) without answers; `quizId` is an HMAC-signed token of the exercise ids and expiry (stateless) |
| `grade_quiz` | free | `{quizId, answers: [{n, answer: ExerciseAnswer}]}` | `{score, results: [{n, correct, expected, explanation, grammarPointId}]}`; adds a `quiz` result to the summary |
| `log_practice` | free, write | `{kind, minutes (1-180), refId?, score?}` | the updated summary |
| `get_weak_areas` | Plus | `{limit? (1-20)}` | `{sounds: [{soundId, ipa, score, attempts, trend}], grammar: [{grammarPointId, title, accuracy, attempts}]}` |
| `get_due_flashcards` | Plus | `{limit? (1-50)}` | `{dueToday, overdue, cards: [{cardId, front, back, due, interval}]}` across devices |
| `get_practice_history` | Plus | `{from?, to?, kind?, limit (1-100), cursor?}` | `{items: Attempt[], nextCursor}` |
| `get_quiz_history` | Plus | `{limit (1-50), cursor?}` | `{quizzes: [{at, score, grammarPointIds}], nextCursor}` |
| `search_phrases` | free | `{query?, situation?, level? (B2-C2), kind?, limit (1-25)}` | `{matches: [{id, text, kind, level, situations, meaning, example, note, audioUrl, pageUrl}], total}` |
| `search_slang` | free | `{query?, fit?, region?, includeDated (default true), limit (1-25)}` | `{matches: [{id, term, meaning, register, fits, region, examples, usageNote, dated, datedNote?, audioUrl, pageUrl}], total}` |
| `get_todays_drills` | free (Plus adds reviews and the plateau track) | `{limit (1-40)}` | `{day, items: [{itemId, kind, reason, say, meaning, tip, audioUrl, pageUrl}], counts: {assigned, due, new, plateau}, note}` |
| `start_spoken_drill` | free | `{source: today\|list\|items\|search, itemIds?, query?, situation?, level?, count (3-20)}` | `{sessionId, step: {n, total, itemId, say, meaning, tip, reps, audioUrl, pageUrl}}`; `sessionId` is an HMAC-signed token of the item ids and expiry (six hours), prefixed `d1.` so it is never a quiz token |
| `next_drill_step` | free | `{sessionId, after (0-30)}` | `{done: false, step}` or `{done: true, itemIds, total}` |
| `get_plateau_progress` | Plus | `{}` | `{onTrack: false}` or `{onTrack, week, weeks, phase, phaseDetail, daysLeft, retestDue, nextRetestDay, errors: [{errorId, title, area, active, baseline, latest, history, trend, status}], ownSentences}` |
| `list_recordings` | Plus | `{itemId?, limit (1-100)}` | `{recordings: [{id, itemId, kind, text, at, durationMs, score, device}], note}`: metadata only, never audio |
| `assign_practice` | free, write | `{itemIds (1-50), note?, remove?}` | `{added, total, unknown}` or `{removed, unknown}`; ids must be phrase-bank or slang ids |
| `log_drill_practice` | free, write | `{items: [{itemId, result: again\|hard\|good\|easy}] (1-50), minutes (1-180)}` | `{logged, streak, note}`; a `shadowing` activity on the summary; Plus: review state at once; free: queued in `practice/inbox` for the device |

The teacher tools (the last nine rows) are section 20.

**Open:** the brief lists the free tools as overview, streak, grammar lookup
and add flashcards. `start_quiz`, `grade_quiz` and `log_practice` are free here
because they touch only content and the summary; the owner may move them to
Plus.

---

## 9. Billing webhooks

Both endpoints read the raw body, verify before parsing anything else, and are
idempotent. Neither ever creates `users/{uid}`: an event for a uid with no
user document, or with a `deletions/{uid}` record, is recorded as
`ignored: no account` and answered `200` (the cancellation Stripe sends after
an account deletion would otherwise bring its billing back). They are
idempotent: the first step is `create()` of `webhookEvents/{source}:{eventId}`
in the same transaction as the state change; an existing document means a
replay, answered `200 {duplicate: true}` with no change. Each one writes
`plusSources.<source>` and recomputes `plus` with `resolvePlus` in that
transaction. Emails go to `mailQueue/{source}:{eventId}:{template}`, so each
event queues each email at most once.

### 9.1 Stripe

`POST https://cadence.pstepanov.dev/api/webhooks/stripe`

- Verify with `stripe.webhooks.constructEvent(rawBody, stripe-signature,
  STRIPE_WEBHOOK_SECRET)`; failure is `400`.
- The Stripe account is shared: ignore (with `200`) anything whose product
  lacks `metadata.app = cadence`.
- The uid comes from Checkout `client_reference_id` and
  `subscription.metadata.firebase_uid` (both set at session creation).
- Events arrive out of order, so the handler re-reads the subscription from
  Stripe; when it cannot (no key, as in the replay harness, or a deleted
  object) it uses the event's copy dated by the event, and an older copy never
  overwrites a newer one (`eventAt` on each source's record).
- Code: `src/lib/server/billing/stripe-webhook.ts` (handler),
  `stripe-map.ts` (pure mapping), `checkout.ts` (`POST /api/billing/checkout`
  `{interval}` and `POST /api/billing/portal`, both answering `{url}`).

| Event | Effect | Email |
| --- | --- | --- |
| `checkout.session.completed` | store `stripeCustomerId`; write the subscription's record | `plus-welcome` (or `trial-started`) |
| `customer.subscription.created` | write record | none (welcome comes from checkout) |
| `customer.subscription.updated` | write record (`active` for `active`, `trialing`, `past_due`; `expiresAt` = current period end; `willRenew` = not `cancel_at_period_end`; `productId` from the price lookup key) | `plus-canceled` when `willRenew` turns false |
| `customer.subscription.deleted` | `active: false` | `plus-ended` |
| `customer.subscription.updated` (product changed) | as above | `plan-changed` |
| `invoice.payment_failed` | no state change (Stripe moves the status) | `billing-issue` (link to the Customer Portal through `/account`) |
| `invoice.paid` (amount above zero) | none | `payment-receipt` with Stripe's hosted invoice link |
| `charge.refunded` | none (a refund that ends Plus arrives as `customer.subscription.deleted`) | `refund-issued` |

The old `src/app/api/stripe/webhook` route is gone; the owner points the
Stripe endpoint at the new URL (docs/DEPLOY.md lists the events). The handler
still keeps the older `users/{uid}.billing` map current for pages that read it.

### 9.2 RevenueCat

`POST https://cadence.pstepanov.dev/api/webhooks/revenuecat`

- `Authorization: Bearer <REVENUECAT_WEBHOOK_SECRET>`, compared in constant
  time; anything else is `401`.
- Only events whose `entitlement_ids` include `plus` change state. An
  `app_user_id` that is not a Firebase uid (an anonymous `$RCAnonymousID`) is
  logged and answered `200`; the app must call `Purchases.logIn(uid)`.
- Sandbox events (TestFlight, App Review) are accepted and marked
  `sandbox: true`; App Review must be able to unlock Plus.

| Event | Effect | Email |
| --- | --- | --- |
| `INITIAL_PURCHASE` | active, `expiresAt` = `expiration_at_ms`, `willRenew` true | `plus-welcome` or `trial-started` (`period_type` `TRIAL`) |
| `RENEWAL` | active, new `expiresAt` | none |
| `CANCELLATION` | `willRenew` false; stays active until `expiresAt` (a refund, `cancel_reason` `CUSTOMER_SUPPORT`, ends it now) | `plus-canceled`, or `refund-issued` for a refund |
| `UNCANCELLATION` | `willRenew` true | none |
| `EXPIRATION` | `active` false | `plus-ended` (none while Stripe still keeps Plus on) |
| `BILLING_ISSUE` | stays active until the grace period ends | `billing-issue` |
| `PRODUCT_CHANGE` | `productId` = `new_product_id` when present | `plan-changed` |
| `TRANSFER` | re-read both uids from `GET /v1/subscribers/{uid}` and rewrite their `app_store` records | none |
| `SUBSCRIPTION_PAUSED` | `willRenew` false, active until `expiresAt` | none |
| `TEST` | recorded, no change | none |

### 9.3 Local harness

`scripts/webhooks/` (server builder), offline by default:

- `node scripts/webhooks/replay-stripe.mjs --url http://localhost:3000/api/webhooks/stripe [--twice]`
  signs the JSON fixtures in `scripts/webhooks/fixtures/stripe/` with
  `STRIPE_WEBHOOK_SECRET` (`stripe.webhooks.generateTestHeaderString`, no
  network) and posts them; `--twice` checks idempotency.
- `node scripts/webhooks/replay-revenuecat.mjs --url http://localhost:3000/api/webhooks/revenuecat [--event BILLING_ISSUE] [--twice]`
  posts RevenueCat sample payloads from `fixtures/revenuecat/` with the bearer
  secret.
- Against Stripe test mode (owner only; it creates test objects):
  `stripe listen --forward-to localhost:3000/api/webhooks/stripe`, then
  `stripe trigger checkout.session.completed`,
  `stripe trigger customer.subscription.updated`,
  `stripe trigger invoice.payment_failed`.

---

## 10. Email

Email through Brevo from `Cadence <hello@cadence.pstepanov.dev>`, replies to
`support@cadence.pstepanov.dev`. Everything event-driven is queued at
`mailQueue/{key}` (often in the transaction that caused it), delivered by the
route's `after()` hook and retried by the five-minute job; the key makes each
message exactly-once. Password reset and verification links are credentials,
so those two are sent directly and never stored.

Code in `src/lib/server/email/`: `layout.ts` (frame and pieces),
`templates/` (pure functions with typed props, and a fixture each in
`templates/index.ts`), `brevo.ts` (send, contacts, double opt-in),
`queue.ts`, `unsubscribe.ts`, `senders.ts`.

Templates: account (`welcome`, `verify-email`, `password-reset`,
`password-changed`, `email-changed` to the old and the new address,
`new-sign-in`, `deletion-scheduled`, `account-deleted`, `data-export-ready`),
billing (`plus-welcome`, `trial-started`, `trial-ending` for web trials only,
`payment-receipt`, `billing-issue`, `plus-canceled`, `plus-ended`,
`plan-changed`, `refund-issued`), security (`mcp-authorized`, `device-paired`,
`suspicious-activity`), support (`support-request` to the inbox with the
writer as reply-to, `support-reply` to the writer) and opt-in
(`streak-at-risk`, `weekly-summary`, `badge-earned`, `inactive-nudge`,
`newsletter-confirm`, `newsletter-welcome`).

Design: tables, at most 560 px, the hosted 2x logo PNG with alt text, one
accent (hunter green, yellow-green in dark mode), Funnel Display through one
Google Fonts link with a system stack behind it, and a single `<style>` block
for the dark palette and phone padding; every other style is inline, so
Gmail (which drops both) still gets the light design. Every email has a
plain-text part; only opt-in mail has an unsubscribe link (and
`List-Unsubscribe` one-click headers).

Firebase's own emails are never used: the server generates the one-time
codes with the Admin SDK and puts them on `/reset-password` and
`/verify-email`; docs/DEPLOY.md has the console setting.

Newsletter: list 5, Brevo double opt-in only (`POST /api/newsletter`); list 4
holds every account for account email and is never used for marketing.
`BREVO_API_URL` points every Brevo call at a local stub for end-to-end tests;
only a loopback `http` address is accepted.

---

## 11. Account deletion and export

`/account` offers **Download my data** (`GET /api/account/export`, JSON of the
user document and every subcollection, the summary and usage) before **Delete
account**. Deletion (`DELETE /api/account`, recent sign-in required), each step
idempotent and retried by the daily job if it fails:

1. RevenueCat `DELETE /v1/subscribers/{uid}`.
2. Stripe: cancel any live subscription now, clear `metadata.firebase_uid`
   and drop our link to the customer; the customer and invoices stay (tax).
3. Brevo: delete the contact.
4. Firestore: `recursiveDelete(users/{uid})`, `usage/{uid}`, the uid's OAuth
   grants and tokens, its rate-limit keys.
5. Firebase Auth `deleteUser`. Queue `account-deleted` to the address first.

---

## 12. Cloud Run topology

Region `us-central1`. `deploy/cloudrun.sh` deploys and docs/DEPLOY.md is
the runbook; the owner runs them, nothing else does.

```
cadence.pstepanov.dev ── Firebase Hosting (CDN)
   ├── /packs/**, /_next/static/**   static, immutable
   └── everything else  ──rewrite──▶ cadence-web  (Cloud Run, public)
                                        │  Google ID token, Direct VPC egress
                                        ▼
                                     cadence-ai   (Cloud Run, internal ingress, IAM only)
cadence-web ──▶ Vertex AI (Gemini), Cloud TTS (+ GCS cache), Firestore, Brevo, Stripe, RevenueCat
Cloud Scheduler ──▶ cadence-web /api/jobs/daily (17:00 UTC), /api/jobs/mail (every 5 min)
```

| Service | Image | Settings |
| --- | --- | --- |
| `cadence-web` | Next.js standalone (`Dockerfile`): web, API, sync, MCP, webhooks | `--allow-unauthenticated --min-instances 0 --max-instances 10 --concurrency 80 --cpu 1 --memory 1Gi --cpu-boost --timeout 60`; service account `cadence-web` with Firestore user, `run.invoker` on `cadence-ai`, Vertex AI user, TTS, the TTS cache bucket, and its own secrets only |
| `cadence-ai` | `src/backend/ai-engine/Dockerfile.cloud` (CPU PyTorch, phoneme model at its pinned safetensors revision and Whisper-small baked in, PyTorch weights only, offline at runtime; `--build-arg ASR_MODEL=` leaves Whisper out) | `--no-allow-unauthenticated --ingress internal --min-instances 0 --max-instances 3 --concurrency 4 --cpu 2 --memory 4Gi --cpu-boost --timeout 60`; no secrets; private until launch |
| jobs | routes on `cadence-web`, called by Cloud Scheduler with `Authorization: Bearer <JOBS_SECRET>` | daily: purge lapsed detail after 90 days, retry deletions, drop uncollected inboxes after 90 days, `trial-ending`, opt-in reminders; every 5 minutes: deliver queued mail |

- **Service to service.** `cadence-web` fetches a Google ID token for the
  `cadence-ai` URL from the metadata server and sends it as a Bearer token.
  Internal ingress only admits traffic from the VPC, so `cadence-web` uses
  Direct VPC egress (`--network default --subnet default --vpc-egress
  all-traffic`) with Cloud NAT for its internet calls.
- **Cold starts.** Both scale to zero. `cadence-web` starts in under 1 s
  locally (1 vCPU); it never loads models. `cadence-ai` answers in under 2 s
  and has both models loaded from local disk in about 3.5 s locally (2 vCPU); the apps show "Warming up" after 3 s. **Open:** the engine's
  `/health` answers 200 while still warming, so Cloud Run's default TCP
  startup probe is used; a `/healthz` that answers 503 until the scorer is
  loaded (ai-engine owner) would let a startup probe hold requests back.
  `cadence-web`'s `/api/health` is `{ok, service}` there; on your own
  Cadence it adds `engines: {ai, coach}` (`reachable`, `ready`), probing each
  engine's `/health` with a 1.5 s timeout. The status probes `GET
  /api/assess` and `GET /api/ai-coach` answer 200 with `ready: false` when
  an engine is down, so polling never logs an error.
- **Secrets** (Secret Manager, mounted as env): `STRIPE_SECRET_KEY`,
  `STRIPE_WEBHOOK_SECRET`, `REVENUECAT_WEBHOOK_SECRET`, `REVENUECAT_API_KEY`,
  `BREVO_API_KEY`, `QUIZ_TOKEN_SECRET`, `EMAIL_UNSUBSCRIBE_SECRET`,
  `JOBS_SECRET`, `ADMIN_SECRET` (the owner's dashboard holds the same value
  as `CADENCE_ADMIN_SECRET`). Settings in `deploy/cadence-web.env.example`.
  The repo never holds a secret.

---

## 13. Mouth map (articulation visuals)

The speech equivalent of Heft's muscle map: a side view of the mouth for every
English phoneme, a front view of the lips, highlighted articulators, animation
between sounds and a compare view. Free for everyone in every mode (static
content, no AI).

### 13.1 Model

`src/lib/platform/vocal-tract/` (and the mobile twin) is a TypeScript port of
the VocalTract LaTeX package by Dimitrios Ververidis (Ververidis, Schneider and
Koehler, "The vocal tract LaTeX package", *The PracTeX Journal* 2012/1),
built on Maeda's articulatory model. Credits and licence in `NOTICE` and
`CREDITS.md`.

| File | Contents |
| --- | --- |
| `maeda.ts` | the loading table, `computeVocalTract(params)` for the 28 movable points and the glottis |
| `geometry.ts` | static anatomy, `buildShape(state)` with fills (`head`, `laryngealWall`, `lowerTract`, `palate`, `tongue`, `upperTeeth`, `lowerTeeth`) and layers (`lips`, `teeth`, `alveolarRidge`, `hardPalate`, `velum`, `tongueTip`, `tongueBlade`, `tongueBody`, `tongueRoot`, `jaw`, `glottis`, `pharynx`, `nasalCavity`, `face`); `placeAnchor`; `frontLips`; `HEAD_VIEW_BOX` |
| `svg-path.ts` | `createViewport`, `subpathToSvg`: the same path strings for SVG and react-native-svg |
| `animate.ts` | `lerpParams`, `easeInOut`, `paramsAt` (diphthong trajectories), `glottisPulse` |
| `fit.ts` | `fitParams(targets)`: box-constrained least squares (every point is linear in the parameters) for the content pipeline |
| `codebook.ts` | the package's 26 German demo vectors, the test reference |
| `articulation.ts` | `ENGLISH_SOUNDS` (24 consonants, GA and RP vowels and diphthongs, ARPAbet ids), `ArticulationTarget`, `validateArticulationTarget` |

Parameters: `jaw`, `tonguePosition`, `tongueShape`, `tongueApex`,
`lipAperture`, `lipProtrusion`, `larynxHeight` (Maeda's seven) plus the
package's `glottalAperture`, `glottalFrequency` (voiced when above -1) and
`velum`. Each runs from -3 to 3.

Animation is parameter interpolation: compute the shape for interpolated
parameters each frame and redraw (a Reanimated shared value drives `t` on the
phone; at about 40 points this is well within a 60 fps frame budget).

### 13.2 English targets

`content/articulation/*.json` (content builder): `{format: 1, targets:
ArticulationTarget[]}` covering every `ENGLISH_SOUNDS` entry, GA and RP
where they differ, diphthongs and affricates as trajectories.

- Fit with `fitParams` to the CC0 "IPA … Sagittal Section.svg" drawings by
  Richard Wright and Dan McCloy on Wikimedia Commons (CC0 confirmed per file
  through the Commons API; URLs listed in `CREDITS.md`), traced into the
  package's coordinates; and to published Maeda-parameter values where they
  exist (cited in `source.references`).
- What the model cannot show (tongue-tip contact, lateral airflow, lip rounding
  from the front, the bunched or retroflex r) is an overlay (`OverlayId`).
- Anything hand-tuned is `source.method: "hand-tuned"`, `needsReview: true`,
  and listed in the content builder's report.
- Not used: Seeing Speech or STAR material (CC BY-NC-ND, no adaptation).

### 13.3 Component and learning logic

- One component per platform: web SVG (`src/components/mouth-map/`), mobile
  react-native-svg plus Reanimated (`mobile/src/components/mouth-map/`). Soft
  fills and clear outlines in the Cadence palette, light and dark. Highlights
  active layers like Heft's muscle map, pulses the glottis for voiced sounds,
  shows an airflow arrow from `placeAnchor`, a front lip view, and a compare
  view for minimal pairs (ship/sheep, light/right, think/sink). Every layer has
  an accessibility label.
- Every pronunciation result links to it: tap a weak sound, see where the
  tongue goes, play the model sound, record again.
- Sound-by-sound diagnosis from the phoneme scores builds a personal
  "sounds to fix" list ordered by `error rate × frequency in English` (phoneme
  frequency from our own count over the Tatoeba English sentences with an
  openly licensed pronouncing dictionary, credited when added).
- Drills climb isolated sound, syllable, word, minimal pair, phrase, sentence;
  a step is passed at three takes in a row at 80 or above. Then shadowing,
  stress and intonation drills, and spaced review of fixed sounds at 1, 3, 7
  and 21 days. Progress per sound over time comes from `mastery/sounds` (Plus)
  or the device.
- Our own words and design throughout. No other product's name, logo, copy,
  lessons, videos, coach persona or screenshots; the website makes factual
  comparisons only, if any.

---

## 14. Security

- **App Check** on every cloud AI, sync and newsletter route: App Attest on iOS
  (`@react-native-firebase/app-check` in the dev-client build; Expo Go uses the
  debug provider), reCAPTCHA Enterprise on the web, the debug provider in
  development. The server verifies `X-Firebase-AppCheck` with the Admin SDK,
  with replay protection on sign-up and newsletter. MCP uses OAuth instead.
- **Rules.** `firestore.rules` and `storage.rules` deny every client; only the
  Admin SDK on the server reads or writes.
- **Web headers** (`src/lib/security/headers.ts`; the fixed ones from
  `next.config.ts` on every path, the CSP per request from `src/proxy.ts`): a
  CSP with a fresh nonce for scripts (`'strict-dynamic'`; `connect-src`
  covers Firebase Auth, App Check and reCAPTCHA; `media-src 'self' blob:`;
  no `upgrade-insecure-requests`, since your own Cadence is plain HTTP on the
  LAN),
  `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload`,
  `frame-ancestors 'none'` (and `X-Frame-Options: DENY`),
  `Referrer-Policy: strict-origin-when-cross-origin`,
  `X-Content-Type-Options: nosniff`, a minimal `Permissions-Policy`
  (microphone on self only).
- **Auth endpoints** (`/api/auth/*`, password reset, sign-up) are rate limited
  per IP and per account (`rateLimits`). The IP is the entry the trusted
  proxies appended to `X-Forwarded-For`, counted from the right
  (`TRUSTED_PROXY_HOPS`: 1 for Cloud Run alone, 2 behind Firebase Hosting,
  which `deploy/cloudrun.sh` sets), so a client cannot pick its own bucket.
- **Audio:** at most `AUDIO_MAX_SECONDS` (30) and `AUDIO_MAX_BYTES` (2 MB);
  the container is sniffed (`sniffAudio`), not taken from the declared type;
  the length that is capped and charged is read from the codec data the way
  a decoder reads it (`src/lib/server/engines/audio-duration.ts`: WAV sample
  rate times block size, refusing a byte rate that disagrees; every Opus
  packet's own frame count in WebM and Ogg; the MP4 sample tables with a
  floor of 1024 samples per AAC frame at 96 kHz; each MP3 frame header),
  never less than bytes over 24,000 per second for compressed audio, and an
  upload whose length cannot be read is refused; processed in memory and
  never stored by default.
- **Coach prompt injection:** fixed system prompt per scenario; learner text is
  passed as quoted data in its own message, never spliced into instructions;
  the model has no tools; output capped (about 250 tokens) and stripped of
  links and markup; spoken grammar output must validate against its schema.
- **Service to service:** `cadence-ai` accepts only Google ID tokens for
  `cadence-web`'s service account, from the VPC.
- **CI** (`.github/workflows/ci.yml`): typecheck, lint, tests, build for web
  and mobile; `pnpm audit --prod --audit-level high`, `npm audit --omit=dev
  --audit-level=high` in `mobile/` and `desktop/`, `pip-audit -r
  src/backend/ai-engine/requirements.txt -r src/backend/coach-engine/requirements.txt`;
  secret scanning with gitleaks; `.github/dependabot.yml` for npm (root,
  `mobile`, `desktop`), pip (both engines), GitHub Actions and Docker.

---

## 15. Missing basics

Dark mode on web and mobile (tokens already mirror `globals.css`); offline
content packs (section 3.3); accessibility labels on every control, image and
mouth-map layer; a progress share card (an image rendered from the stats
screen, no personal data beyond streak and totals); empty states that name the
next step ("No cards due. Start today's plan").

---

### 15.1 Web pages and the routes they call

The web UI (`src/app`, `src/components`, `src/hooks`) calls the server only
through `cloudFetch` (`src/hooks/cloud-fetch.ts`), which adds the App Check
token (`X-Firebase-AppCheck`, limited-use for sign-up flows and the newsletter)
and, when signed in, the Firebase ID token.

| Page | Calls |
| --- | --- |
| `/forgot-password` | `POST /api/auth/password-reset {email}`; same answer whether or not the account exists; 60 s browser cooldown; Firebase's own email if the route is missing |
| `/reset-password` | Firebase `confirmPasswordReset` (revokes every session), then `POST /api/auth/password-changed {email}`, then signs this device in; passes `verifyEmail`, `verifyAndChangeEmail` and `recoverEmail` links on to `/verify-email` |
| `/verify-email` | `applyActionCode` for the link; resend is `POST /api/auth/verify-email` |
| `/newsletter`, footer, sign-up box, `/account` switch | `POST /api/newsletter {email, source, consent: true, platform}` (Brevo double opt-in, list 5); Brevo's confirmation lands on `/api/newsletter/confirmed`, which redirects to `/newsletter/confirmed`; the account switch turns it off with `DELETE /api/newsletter` (**Open**: not built yet; the page points to the unsubscribe link meanwhile) |
| `/pricing`, `/checkout?plan=`, `/account` | `POST /api/billing/checkout {interval}` and `POST /api/billing/portal`, both `{url}`; Plus status from `GET /api/me` |
| `/account` | `GET /api/account/export`; `DELETE /api/account` after re-entering the password |
| `/contact` | `POST /api/support` (the form; `/support` holds the quick answers and links here) |
| `/redeem?code=` | `GET /api/codes/redeem?code=` once for a code from a link, then `POST /api/codes/redeem {code}`; web only, never linked from the iPhone app |
| `/practice/*`, `/grammar/*` | packs from `/packs` (built-in starter pack per level until they exist); each round is `POST /api/sync/summary {activities}` when signed in |
| `/today`, `/phrases`, `/phrases/<id>`, `/phrases/practice`, `/slang`, `/slang/<id>`, `/slang/quiz`, `/plateau`, `/recordings` | the advanced packs from `/packs`; state in localStorage (`cadence.advanced.v1`), recordings in IndexedDB (`cadence-recordings`); signed in, `GET`/`PATCH /api/practice`; with Plus, `POST /api/sync/advanced` (`src/components/advanced/store.ts`). `/today` is the first web screen that calls `buildDailyPlan` |
| `/practice`, every flashcard review | `src/components/learn-hub/sync.ts`: `GET`/`DELETE /api/sync/inbox` for every account (connector cards join the deck); with Plus, `POST /api/sync/import` once per browser, then `POST /api/sync/push` a few seconds after reviews and `GET /api/sync/pull?since=`, last writer wins per card (the phone's body shapes, `sync-logic.ts`) |
| AI calls (assess, transcribe, coach, voices) | `{ai: true}`: a refusal (`needs_plus`, `daily_limit`, …) opens one banner offering "Connect your own Cadence" and Plus |

`/sounds`, `/sounds/<soundId>` and `/sounds/compare` read
`content/articulation/*.json` on the server (falling back to
`src/components/mouth-map/fixture-targets.json`); every pronunciation result
links each sound to its page with a "Record again" link back, and records the
scores on the device for "sounds to fix" (`src/components/mouth-map/sound-practice.ts`).
`/connect-phone` shows the pairing QR when the browser holds the pairing key,
otherwise the steps. `/connector` explains adding the MCP connector,
`/download` the desktop builds and the iPhone app (`NEXT_PUBLIC_APP_STORE_URL`
once it is live), and `/credits` the credits and licences from `CREDITS.md`. Dark mode
follows the system or the `cadence_theme` cookie; `public/sw.js` keeps packs
offline.

## 16. Test matrix

Run from the repo root unless a row says otherwise. "Exists" rows run today;
the rest are added by the stage that builds the feature, with exactly these
commands.

### Shared

| What | Command | Pass |
| --- | --- | --- |
| Drift between the twins | `pnpm test` (`tests/platform/drift.test.ts`) and `node scripts/platform/sync-mobile.mjs --check` | identical bodies, same file set (exists) |
| Content model, validators, grading | `pnpm test` (`tests/platform/content-model.test.ts`) | all pass (exists) |
| Engine routing, entitlement, quotas, audio sniffing | `pnpm test` (`tests/platform/engine-routing.test.ts`) | all pass (exists) |
| Summary and streaks | `pnpm test` (`tests/platform/progress-model.test.ts`) | all pass (exists) |
| Vocal-tract port | `pnpm test` (`tests/platform/vocal-tract.test.ts`); refresh the reference with `node scripts/vocal-tract/make-reference.mjs` (needs TeX Live) | every point of all 26 demo phonemes within 1e-4 of the package (exists) |
| SRS scheduling | `pnpm test` (`tests/platform/srs.test.ts`, moved from `mobile/tests/srs.test.ts`) | all pass |
| Daily plan, placement scoring | `pnpm test` (`tests/platform/daily-plan.test.ts`, `placement.test.ts`, `adaptive-placement.test.ts`, `levels.test.ts`) | plan fits 10-15 minutes; deterministic for fixed input; simulated learners at every level placed at their level at least 75% of the time and never more than one level off; retakes ask fresh items; level settings parse and the newer copy wins |
| Content packs | `node scripts/content/validate.mjs` | zero problems across every pack, including at least 60 placement items and all seven types per level |
| Articulation targets | `node scripts/content/validate-articulation.mjs` | every `ENGLISH_SOUNDS` entry has a valid target per variant; `needsReview` list printed |
| Phrase bank, slang, plateau track, recordings index | `pnpm test` (`tests/platform/phrase-bank.test.ts`, `fossilization.test.ts`, `practice-day.test.ts`, `recordings.test.ts`, and the plateau rows of the daily plan) | drills grade as documented; reviews go through the one scheduler; the program's weeks, phases, re-tests and progress per error; the plan still fits 10 to 15 minutes with the track and phrase reviews in it; eviction and metadata never carry audio or file names |
| Advanced content | `node scripts/content/validate.mjs` (`advancedProblems`) | at least 3,000 phrases (600 per level, 60 per situation), 300 slang entries, 25 plateau errors; every record passes the shared validators; grammar points and sounds named by an error exist |

### Email

| What | Command | Pass |
| --- | --- | --- |
| Templates render | `pnpm test` (`tests/email/render.test.ts`) | every template renders from its fixture (`src/lib/server/email/templates/index.ts`) with an HTML and a plain-text part, no unreplaced placeholders, unsubscribe only on opt-in mail |
| HTML lint | `node --import ./tests/register.mjs scripts/email/lint.ts` | one `<style>` in `<head>` and the font `<link>` only, inline styles everywhere else, every `<img>` with `alt` on https, 560 px frame, under 100 KB |
| Previews | `node --import ./tests/register.mjs scripts/email/preview.ts` | `build/email-previews/index.html`, light and dark |
| Forgot password end to end | `firebase emulators:exec --only auth,firestore --project demo-cadence "pnpm test:e2e -- tests/e2e/reset-password.spec.ts"` | request sends a link; `/reset-password` accepts it; new password signs in; old one fails; one `password-changed` in `mailQueue` |
| Billing emails exactly once | in the server run below (`tests/server/emulator/webhooks.test.ts`) | each Stripe and RevenueCat event queues its template once; a replay queues nothing |

### Server

| What | Command | Pass |
| --- | --- | --- |
| Route tests | `firebase emulators:exec --only auth,firestore --project demo-cadence "node --test --test-concurrency=1 --import ./tests/register.mjs 'tests/server/**/*.test.ts'"` (JDK 21+) | sync routes respect tiers and App Check; quotas return 429; circuit breaker returns 503 |
| Webhooks | same run (`tests/server/emulator/webhooks.test.ts`), plus `node scripts/webhooks/replay-stripe.mjs --twice` and `node scripts/webhooks/replay-revenuecat.mjs --twice` against `pnpm dev` | bad signature or bearer is 400/401; every listed event maps per section 9; replays are `duplicate: true` with no change; `plus` correct with two sources |
| MCP teacher tools | same run (`tests/server/emulator/mcp-teacher.test.ts`); pure parts in `pnpm test` (`tests/server/teacher.test.ts`) | output keys as section 8; audio links only where the file exists; a spoken drill steps through and ends with the ids; a forged or expired session is refused, and a quiz token is never a drill token; free logging queues for the device, Plus logging schedules reviews; Plus tools refuse a free account; recordings come back as metadata only |
| MCP | same run (`tests/server/emulator/mcp.test.ts`) | no token: 401 with `WWW-Authenticate` and `resource_metadata`; wrong audience: 401; GET and DELETE: 405 after auth; read-only scope cannot call write tools; free account gets the Plus error on Plus tools; every tool's output matches section 8; the 31st call in an hour on free is rate limited |
| Firestore rules | `firebase emulators:exec --only firestore --project demo-cadence "node --test tests/rules/firestore.test.ts"` (`@firebase/rules-unit-testing`) | every read and write from an unauthenticated and an authenticated client is denied, on every collection in section 5 |
| Support and friend codes | same run (`tests/server/emulator/support-and-codes.test.ts`); pure rules in `pnpm test` (`tests/server/support-and-codes.test.ts`) | the form stores a request and queues one `support-request` with the writer as reply-to; the honeypot stores nothing; the sixth message in an hour from one IP is 429; admin routes refuse without `ADMIN_SECRET`; a reply queues `support-reply` and marks it answered; codes follow the dashboard contract (201, 409, 415, no lifetime codes, revoke); redeeming writes `plusSources.code` for the code's days and Plus ends with it; a subscription is never touched; ten tries an hour |
| Python engines | `python3 -m py_compile src/backend/ai-engine/main.py src/backend/coach-engine/main.py` and `cd src/backend/ai-engine && python3 -m pytest` (`pip install -r requirements.test.txt` once) | compile; size, duration and MIME limits refuse bad audio (`audio_limits.py`, the same rules as `engines/audio.ts`) |

### Web

| What | Command | Pass |
| --- | --- | --- |
| Typecheck, lint, unit | `pnpm typecheck && pnpm lint && pnpm test` | clean (exists); includes the security headers (`tests/web/security-headers.test.ts`), web sync bodies against the server's validators (`tests/web/sync-logic.test.ts`), and audio length, client address and known-client parsing (`tests/server/guards.test.ts`, fixtures in `tests/server/fixtures/audio/`) |
| Production build | `pnpm build` | succeeds (exists) |
| Smoke flows | `pnpm exec playwright install chromium` once, then `firebase emulators:exec --only auth,firestore --project demo-cadence "pnpm test:e2e"` (JDK 21+; `playwright.config.ts` builds with demo Firebase values and starts `pnpm start` on port 3310; Stripe Checkout is stubbed by route interception, Brevo by `tests/e2e/support/brevo-stub.mjs` through `BREVO_API_URL`; `E2E_REUSE_BUILD=1` skips the build) | landing; sign up and in; a lesson; a quiz; flashcards; checkout redirects to the stubbed URL; the connector consent page (`tests/e2e/oauth-consent.spec.ts`: discovery, sign in, allow, code for a token, deny, unknown client, security headers); local mode with no account; mouth map animates; the newsletter sends one Brevo double opt-in request for list 5 and never adds to list 5 directly; all at widths 375, 768 and 1280 with no horizontal scroll and no console errors; screenshots in `build/test-screenshots/web/<width>/` |
| Accessibility | in the same run, `@axe-core/playwright` on every visited page | no serious or critical violations |
| Lighthouse | `pnpm exec lhci autorun` after `pnpm build` (`lighthouserc.json`: landing and dashboard, Lighthouse's default mobile settings, median of 3; the local-mode cookie is sent on both so the dashboard opens; reports in `build/lighthouse/`) | performance at least 85, accessibility at least 95, best practices at least 95 |
| Bundle budget | `node scripts/budgets/web.mjs` after `pnpm build` | within the budgets below |

### Desktop

| What | Command | Pass |
| --- | --- | --- |
| Build | `cd desktop && pnpm build:mac` | DMG produced in `desktop/packages/` (exists) |
| Launch smoke | `node desktop/scripts/smoke.mjs` (Playwright `_electron`, the packaged app on a throwaway profile); `--dmg desktop/packages/Cadence-X.Y.Z-arm64.dmg` installs it from the DMG first, into a temporary folder | window opens; local mode reaches the dashboard without an account; `/pair` renders a QR; `/api/health` reports both engines ready within the setup timeout; a lesson works with every non-loopback request blocked |

### Release

| What | Command | Pass |
| --- | --- | --- |
| Version rules, bump plans, manifest | `pnpm test` (`tests/release/`) and `node scripts/release/bump.mjs <product> <kind> --dry-run` for each command in docs/RELEASING.md | all pass; each plan writes the documented files and tag; an empty changelog section is refused |
| Workflow lint | `actionlint .github/workflows/*.yml` (`brew install actionlint shellcheck`) | no findings |
| Updater, fake feed | `cd desktop && pnpm test:update-feed` | update found, downloaded and verified |
| Updater, install | `CADENCE_TEST_SIGN_IDENTITY="Apple Development: …" node desktop/scripts/test-update-install.mjs` after `pnpm build:mac` (Squirrel installs only signed updates; any local development identity works, nothing leaves the machine) | 99.0.0 offered, downloaded, "Update ready" with Restart, applied on quit, and the restarted app reports 99.0.0 |
| `/api/version` | `curl -s http://127.0.0.1:3310/api/version` during the web run | equals `release/manifest.json` |

### Mobile

Run in `mobile/`. Simulators: "iPhone SE (3rd generation)" and
"iPhone 16 Pro Max". Never a physical iPhone.

| What | Command | Pass |
| --- | --- | --- |
| Typecheck, unit | `npx tsc --noEmit && npm test` | clean (exists); includes the bundled advanced packs and the stored advanced state (`tests/advanced.test.ts`) |
| Simulator builds | `npx expo run:ios --device "iPhone SE (3rd generation)"` and `npx expo run:ios --device "iPhone 16 Pro Max"` | build, install, launch, no red box |
| Flows | Maestro (`brew install mobile-dev-inc/tap/maestro`, JDK 17+), `e2e/run.sh <simulator udid> <name> [light\|dark]` against a release build made with the e2e environment (`.env.example`: a `demo-` Firebase project, `EXPO_PUBLIC_FIREBASE_AUTH_EMULATOR`, `EXPO_PUBLIC_PURCHASES_STUB=1`), a Cadence server and the Auth and Firestore emulators; the script header lists its variables | connect own server with no paywall shown; cloud sign-in; a lesson; a quiz; flashcards; matching; sentence building; paywall with RevenueCat in sandbox or the offline stub (`EXPO_PUBLIC_PURCHASES_STUB=1`); airplane mode keeps practice working and shows the AI offer instead of an error; mouth map compare view; the advanced screens (`e2e/11-advanced.yaml`: hub, phrase bank, slang, plateau diagnostic, recordings) |
| Screenshots | flows call `takeScreenshot`; `e2e/run.sh` writes them to `build/screenshots/<name>-<theme>/` (not committed) | every screen captured on both devices, light and dark |
| Dynamic Type | `xcrun simctl ui booted content_size accessibility-extra-extra-extra-large`, then the flows again | no clipped or overlapping text, every action reachable, no crash |
| Crash check | `xcrun simctl spawn booted log show --last 10m --predicate 'process == "Cadence"' \| grep -i -E "fatal\|exception"` after the flows | nothing |

### Optimization budgets

| What | How | Budget |
| --- | --- | --- |
| Web first-load JS per route | `node scripts/budgets/web.mjs` (gzip level 9 of each route's first-load chunks in `.next/diagnostics/route-bundle-stats.json`; the mouth map chunks are those holding the vocal-tract model) | landing at most 150 KB gzip; app routes at most 250 KB; mouth map chunk at most 25 KB |
| Mobile JS bundle | `npx expo export --platform ios` then size of the Hermes bundle | at most 8 MB |
| Mobile cold start | launch to first interactive screen on the SE simulator, median of 5 (`xcrun simctl launch` timestamps against the app's first-render log line) | at most 2.5 s |
| Bundled packs | sum of bundled `public/packs` | at most 30 MB in the iOS app |
| Content pack | `content.json` per level | at most 1.5 MB raw, 300 KB gzip |
| `cadence-web` image | `docker build -t cadence-web . && docker image inspect cadence-web --format '{{.Size}}'` | at most 400 MB; cold start to first byte at most 3 s locally (`docker run` to first `200` on `/api/health`) |
| `cadence-ai` image | same for `src/backend/ai-engine/Dockerfile.cloud` (context `src/backend`), started with `--cpus 2 --memory 4g` | at most 2.5 GB; ready at most 20 s on 2 vCPU |
| Firestore per session | emulator counts in the server route tests (`tests/server/emulator/session-cost.test.ts`) | free at most 2 reads and 1 write; Plus at most 10 reads and 5 writes |

`scripts/budgets/*.mjs` enforce these numbers; change them here and in the
script together.

---

## 17. Phrase bank and modern slang

"Learn phrases, not words": fluent speech is built from ready-made chunks,
so the bank teaches multi-word expressions with a natural example rather
than single words. Static content, free for everyone in every mode, offline.

**Phrases** (`Phrase` in `phrase-bank.ts`): `id` (`phrase.<slug>`,
permanent), `text` (dictionary form), `kind` (`chunk`, `collocation`,
`frame`: the fixed opening of a sentence pattern), `form` (the exact words in
the example, e.g. "raised a concern"), `level` (B2, C1, C2), `situations`
(meetings, negotiation, small talk, disagreeing politely, storytelling,
academic, interviews, travel, presenting, giving feedback, persuading,
explaining, reacting and feelings, problem solving, socialising, calls and
video calls), `meaning`, `example` (contains `form` once), `plain` (the same
idea without the phrase, for the rephrase drill), `note` (register, tone, a
trap) and `audio` (the example's pre-generated file). Packs `phrases-b2`,
`phrases-c1`, `phrases-c2`; a level past 1,800 phrases is split into parts
(`phrases-c1-2`, ...) so every `content.json` stays inside the size budget
as the bank grows, and every reader takes any `phrases-*` pack.

**Drills**, in this order in a session (`drillsForPhrase`): listen and
repeat (three times, matching the rhythm), gap fill (the example with `form`
blanked and an initials hint; `gradeGapFill` accepts the form or the
dictionary form), rephrase (`plain` said again with the phrase; `gradeRephrase`
accepts any verb form of a phrase of three words or more) and shadowing.
Spoken steps record the learner for A/B comparison (section 19).

**Slang** (`SlangEntry`): `id` (`slang.<slug>`), `term`, `partOfSpeech`,
`meaning`, `register` (informal, very informal), `fits` (texting, with
friends, fine at work, not at work; never both of the last two), `region`
(US, UK, global), `category`, two or three `examples`, `usageNote` (who says
it and how it sounds), `dated` with `datedNote` (still understood but a few
years old), `popularSince`, and two stored quizzes: `contextQuiz` (where it
fits, four options) and `replyQuiz` (the natural reply to a message, three or
four). `buildSlangQuiz` asks those or the meaning (distractors from other
entries), shuffled by a seed so every device asks the same.

**Review.** Phrase and slang items are scheduled by the one scheduler
(`srs.ts`), keyed by item id: `gradeFromAnswer` (wrong is again, right after
a retry is hard), `gradeFromScore` for a scored take, `gradeFromSelf` (again,
close, clean) after listening back. `planItemReview` and `dailyNewOrder` (new
items in an order fixed per day, the same on every device).

**Pipeline** (`scripts/content/`): `phrases.mjs` drafts 80 phrases per
situation and level a round with Gemini, in our own words and never from a
published list; a blind check gives a checker each phrase with its example
and four meanings (the key and three from other phrases) and asks it to pick
one and to say whether a fluent speaker would really say it; a miss goes to
a stronger judge (a wrong key is dropped, a checker slip kept); unnatural
phrases and anything rated A1 or A2 are dropped. Round 1 is the starter bank;
`--round 2`, `--round 3` add phrases with everything already written
excluded, which is how the bank grows towards 10,000 without renaming
anything. The same phrase in several situations is kept once at its lowest
level, with the situations merged. `slang.mjs` drafts about 40 terms per
category; a blind check answers the meaning, context and reply quizzes
without the key (any miss drops the entry), and a recency and
appropriateness review drops slurs and sexual, drug, demeaning or obsolete
terms and marks dated ones. The profanity list applies to every text.

---

## 18. The plateau track (fossilization)

For C1 and C2 speakers whose remaining errors have set because nobody
corrects them any more. A 10 to 12 week program (12 by default) on the
errors that persist, with short daily drills and a re-test every week.

**Errors** (`FossilError`, pack `fossilization`, 28 to start, outline in
`scripts/content/data/fossilization-plan.mjs`): grammar (present perfect for
duration, articles with general nouns, third-person -s in fast speech,
uncountable nouns, indirect question order, "will" in if-clauses, gerund or
infinitive, concession linkers, wishes, reporting verbs, time words), word
choice (dependent prepositions, make and do, false friends), pronunciation
(the TH sounds, ship and sheep, V and W, R and L, voiced finals, schwa, cup,
cat and cot), stress (long words, noun and verb pairs, sentence stress) and
intonation (contrastive stress, question tags, linking). Each carries the
grammar points and sounds whose feedback counts as evidence, contrasts
(wrong, right, note), drill sentences, probes (a sentence to correct, or one
to read aloud), minimal pairs and stress-marked sentences. `fossilization.mjs`
drafts them; a blind check corrects every wrong sentence and probe without
the key, and a judge rejects any "wrong" sentence that is in fact fine, any
correction it disputes and any drill sentence that is not natural.

**Evidence and diagnosis.** `evidenceFromGrammarIssues` maps spoken-grammar
feedback (section 7) onto errors by grammar point; `evidenceFromPhonemes`
maps a take's worst score on an error's sounds (below 70 is a miss); the
diagnostic (`diagnosticItems`: two written probes per grammar or word-choice
error, one read-aloud per spoken one, about 40 items) counts twice. An error
is persistent at a 40% miss rate with two diagnostic misses or misses on two
different days, so one bad afternoon never starts a program. `startTrack`
focuses on the four worst.

**The program.** Weeks 1 and 2 notice (all focus errors, contrasts and
pairs first), the middle rebuilds (two errors at a time, rotating weekly,
fixed ones skipped), the last third automates (all of them, shadowing and
full sentences first). `dailyDrills` fills about ten minutes round-robin
across the week's errors, due steps before new ones, and gives a fifth of
the time to the learner's own corrected sentences (`addOwnSentence`, at most
40). Each step is rated after listening back (`recordDrill`, the one
scheduler). On the last day of each week `retestDue` asks a re-test of one
fresh probe per focus error (never a diagnostic item); `errorProgress`
reports baseline, history, trend, and persistent, improving (15 points over
the baseline) or fixed (two re-tests in a row at 85 or more).

**Daily plan.** `buildDailyPlan` takes `plateau: {steps, retestDue}` and puts
the track right after due flashcards (4 minutes, or 5 for a re-test), and
`dueItems` (phrase and slang reviews, at most 3 minutes) after that; the plan
still fits 10 to 15 minutes. `buildPracticeDay` lists the same day's items
with what to say.

Stored on the device for everyone (localStorage `cadence.advanced.v1` on the
web, AsyncStorage `cadence_advanced:<learner>` on the phone) and, with Plus,
in `users/{uid}/advanced/state`, the newer copy winning by `updatedAt`.

---

## 19. Recordings

On every phrase, slang example, plateau step and diagnostic item the learner
can record a take, keep it, and play it next to the target: Target, You, or
A/B (target then take). The target is the pack's pre-generated audio, else
the coach voice from the learner's own Cadence or, with Plus, the cloud
(`/api/reference-audio`, asked quietly so a refusal raises no offer), else
the device's own voice (expo-speech on the phone, `speechSynthesis` in a
browser).

**Where the audio lives.** Only where it was made, never uploaded to the
Cadence cloud:

- iPhone: the app's documents directory, `Documents/recordings/<id>.wav`,
  with `index.json` beside it (`mobile/src/recordings/store.ts`). Export and
  share through the share sheet (Files, AirDrop, a message) under a readable
  name (`exportName`).
- Optional iCloud: a copy of each take in a Cadence folder in the learner's
  own iCloud Drive (`mobile/src/recordings/icloud.ts`, the local native module
  `modules/cadence-icloud`), off by default, turned on from the Recordings
  screen. It needs a build with the iCloud Documents entitlement
  (`CADENCE_ICLOUD=1` makes `mobile/app.config.js` add
  `plugins/with-icloud-recordings.js`); without it the screen shows no iCloud
  switch and everything stays on the phone. **Open (owner, developer portal):** before
  any build with `CADENCE_ICLOUD=1`: in Certificates, Identifiers & Profiles
  create the iCloud container `iCloud.dev.pstepanov.cadence`; on the App ID
  `dev.pstepanov.cadence` enable the iCloud capability with "iCloud
  Documents" (CloudKit not needed) and assign that container; regenerate the
  development and App Store provisioning profiles (automatic signing does it
  on the next archive with `-allowProvisioningUpdates`). Then archive with
  `CADENCE_ICLOUD=1 npm run ios:archive`. The privacy policy should say that
  the copy goes to the learner's own iCloud, never to Cadence.
- Web: IndexedDB (`cadence-recordings`) in that browser. The desktop app
  keeps it in its own local data folder, since Electron stores IndexedDB in
  the app's profile directory.

**Limits** (`recordings.ts`): at most 10 takes per item (the oldest goes
first) and 1,000 in all, 30 seconds a take. The Recordings library shows
them by item or by date with play, A/B, export and delete.

**Plus** syncs only metadata (`metadataForSync`: id, item, kind, text, time,
length, score, device; never a file name or audio) to
`users/{uid}/advanced/state.recordings`, so the learner's assistant can see
what was practised (`list_recordings`).

---

## 20. The connector as a teacher

The learner's assistant can coach through the connector (section 8, the
teacher rows; `src/lib/mcp/teacher-tools.ts`, content read by
`src/lib/mcp/advanced-content.ts`, Firestore in
`src/lib/server/mcp-teacher-store.ts`):

- browse and search the phrase bank and slang (`search_phrases`,
  `search_slang`), each item with an `audioUrl` to the pack audio when it
  exists and a `pageUrl` to the item's web page;
- today's drills (`get_todays_drills`, the same `buildPracticeDay` the apps
  use, by UTC day): free accounts get the assigned list and the day's new
  phrases at their level; Plus adds reviews due and the plateau steps from
  the synced state;
- assign items to the practice list (`assign_practice`), which every device
  picks up from `GET /api/practice` and puts first;
- a hands-free spoken drill (`start_spoken_drill`, `next_drill_step`):
  stateless, one sentence at a time with what it means, a tip and how many
  times to say it; the session id is signed with `QUIZ_TOKEN_SECRET` under
  its own `d1.` prefix;
- log practice (`log_drill_practice`): a `shadowing` activity on the
  summary for everyone; with Plus each result is applied to review state at
  once (`applyConnectorReviews`), otherwise it waits in
  `practice/inbox.reviews` and the device applies it on its next open;
- Plus only: the plateau track's progress (`get_plateau_progress`) and the
  recordings' metadata (`list_recordings`; audio is never available).

Tiers follow section 4.1: static content is free; anything kept in the cloud
about the learner's practice beyond the summary is Plus. The server
instructions tell the assistant to keep spoken turns short, never read ids
or JSON aloud, give one specific note per sentence, and rate results
honestly.
